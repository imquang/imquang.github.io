function changeLogo() {
    var lg = document.getElementsByClassName("brand-logo")[0]
    lg.innerHTML = "Javascript test";
    lg.style.color = "black";
}